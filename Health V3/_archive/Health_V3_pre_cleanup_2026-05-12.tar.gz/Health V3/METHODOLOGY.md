# Client Health Score — Methodology Overview

**Version:** 3.1 | **Last Updated:** May 2026

---

## Executive Summary

### The Problem We Were Solving

SuperCat's previous client health model (V2) had grown difficult to trust and difficult to explain. It incorporated risk modifiers, growth signals, and weighted inputs that were not grounded in data — they were gut-feel coefficients that accumulated over time. The result was a score that was hard to interpret ("why did this client drop 12 points?"), hard to defend in a client conversation, and structurally conflated two separate questions: *is this client healthy today?* and *is this client growing?*

CS was left either ignoring the score or reverse-engineering it. Neither is what a health score is for.

### What We Set Out to Build

The goal of V3 was to start over with a simpler, more honest model built around one question: **is this client actually using and benefiting from SuperCat right now?**

Four things had to be true about the new model:
1. **Explainable in one sentence per dimension.** A CS rep reading the output should know exactly why a score is what it is and what to do about it — without a decoder ring.
2. **No growth signals.** Expansion and upsell are a separate conversation. Health is about the current state of the relationship, not the opportunity.
3. **No invented weights.** Weighting dimensions against each other implies we know which dimensions best predict churn. We don't — not yet. Equal weights are honest; gut-feel weights create false precision.
4. **Grounded in real data before shipping.** Before finalizing thresholds, we ran empirical research across the full 104-org portfolio to see what the actual distributions looked like. Every key threshold in the model was validated against or derived from that research.

### What We Built

V3 is a composite score (0–100) built from four equal dimensions — Engagement, Adoption, Value Delivery, and Operational Health — each contributing 25%. The score runs monthly, covers every active paying client, and produces a health band (Thriving / Healthy / Watch / At Risk / Critical) alongside a plain-English narrative for each dimension.

Two safety overrides cap the composite downward when behavior tells a story the averages alone would miss: a Ghost Account override (high-ARR clients with zero logins) and a Behavioral Floor (clients who are barely showing up and generating no observable outcomes).

Thresholds for each signal were set by looking at the actual portfolio distribution — not by estimating what "should" be normal. Key design choices like equal dimension weights and unweighted point systems for Adoption and Value Delivery were made deliberately, with a documented plan to revisit them once real churn outcome data is available.

### Where We Are Now

V3.1 has completed its first full run across all 104 active clients (May 2026). The run reflects all empirical calibration changes: velocity-based engagement (replacing a recency signal that had zero discriminating power on this portfolio), frequency-weighted data freshness, corrected denominator handling for large-bundle orgs, and exclusion of three import types with systematic parser errors.

The output is a monthly CSV that CS can use immediately to prioritize outreach. The roadmap from here — trigger alerts for score drops, churn-pattern recognition, and save-play playbooks — is staged in the spec and depends on accumulating monthly history before each next step can run responsibly.

---

## 1. What This Is

The Client Health Score is a monthly signal that tells us how each client is actually using and benefiting from SuperCat — expressed as a single number between 0 and 100. It exists because we need a consistent, objective way to know which accounts need attention before they churn, which ones are thriving, and how to prioritize CS time across a large portfolio. The score runs once per month, covers every active client, and produces both a summary number and a plain-English explanation of what's driving it. New accounts in their first 90 days are excluded — during onboarding, a different metric (Time to First Value) is more appropriate than a health score.

---

## 2. How the Score Is Built

The composite score is a simple average of four equal dimensions: **Engagement**, **Adoption**, **Value Delivery**, and **Operational Health**. Each dimension scores 0–100 and contributes exactly 25% to the composite. No dimension outweighs another at this stage — that weighting decision is intentionally deferred until we have enough outcome data (retention, ARR change) to know which dimensions actually predict churn for each product tier.

A score of 80 or above means things look good across the board. A score below 40 is a signal to act. Each account also carries two possible safety overrides — Ghost Account and Behavioral Floor — that can cap the composite downward when behavior tells a story the averages alone might miss.

---

## 3. How Each Dimension Is Scored

### Engagement — Are users actually showing up?

Engagement measures login activity across three lenses, then averages them.

| Signal | What It Measures | High Score | Low Score |
|--------|-----------------|------------|-----------|
| Login volume (90 days) | Raw number of logins in the last quarter | 3,000+ logins | 0–49 logins |
| Active user ratio | Share of enabled users who have logged in at least once in 90 days | 90%+ of team is active | Under 25% ever logging in |
| Login velocity | Whether the pace of logins is holding steady, accelerating, or fading compared to the prior six months | Pace is holding or growing | Pace has dropped sharply — users logged in early and went quiet |

A client can log in frequently but still score poorly on velocity if usage was high early on and has dropped off. This is intentional — it catches the "great launch, slow fade" pattern that raw login counts miss.

---

### Adoption — Are they using what they have?

Adoption measures feature breadth. Each feature the client is configured to use counts as one point. Using it = 1 point; not using it = 0. The score is the share of applicable features the client is actually using.

Critically, a feature only counts if it's actively turned on in the client's configuration. No client is penalized for not using something that was never set up for them.

| Feature | How Usage Is Measured |
|---------|-----------------------|
| iPad App (core) | At least one login in the last 90 days |
| Smart Stacks | At least one smart stack created |
| Sharing / Quoting | At least one email draft (item or document) in 90 days |
| eCat Online Catalog | Portal traffic in the last 90 days (if catalog is enabled) |
| Online Ordering / B2B Cart | Portal order submitted in the last 90 days (if cart is enabled) |
| Sales Portal | Rep opened the Sales Portal section of the app in the last 90 days (if enabled) |
| Inventory Management | Inventory feed imported in the last 90 days (if an inventory feed has been active) |
| Sales Data | Sales data imported in the last 90 days (if sales data is configured) |

Every client has at least three applicable features (iPad, Smart Stacks, Sharing). Most have more depending on their subscription tier.

---

### Value Delivery — Are they getting real outcomes?

Value Delivery applies the same point-per-channel logic as Adoption, but focuses on whether the platform is producing observable business results — not just whether features are turned on and touched.

| Activity | What Qualifies | If Configured But Not Happening |
|----------|---------------|----------------------------------|
| iPad order volume | 10+ submitted iPad orders in the last 90 days | Low conversion of iPad activity into orders |
| Sharing activity | 3+ email drafts (item or document) in the last 90 days | Reps are not using sharing/quoting in the field |
| Online catalog engagement | Portal traffic in the last 90 days (if catalog enabled) | Catalog is live but customers aren't visiting |
| Portal ordering (B2B Cart) | Any portal orders in the last 90 days (if cart enabled) | Cart is configured but not generating orders |
| Sales Portal engagement | Any portal orders in the last 90 days (if Sales Portal enabled) | Portal is set up but not driving activity |
| Inventory data flowing | Inventory imported at least once in the last 90 days (if feed is active) | Feed has gone silent |

Thresholds are intentionally low. The question being answered is "is this channel producing anything?" not "is it producing enough?" Volume calibration comes in a later iteration.

---

### Operational Health — Is the data infrastructure in good shape?

Operational Health has three sub-signals, averaged equally.

**1. Catalog Completeness** — what share of active products have a name, an image, and a price? A well-maintained catalog is the foundation of every other outcome. A catalog that's 90%+ complete scores 100; 60–89% complete scores 60; below 60% scores 20.

**2. Import Health** — for every data feed the client actively runs (products, inventory, sales data, etc.), did the most recent run succeed? The score is the share of active feed types with a clean last run. Imports with only warnings (not errors) count as successful.

**3. Data Freshness** — is each data feed running on its own normal cadence? Freshness is measured relative to each client's historical rhythm, not a universal clock. A daily inventory feed that hasn't run in three days is in worse shape than a quarterly product re-load that's two weeks behind. Feeds that have drifted significantly beyond their own cadence drag this score down.

---

## 4. Health Bands

| Band | Score Range | What It Means for CS |
|------|-------------|----------------------|
| Thriving | 80–100 | Account is in good shape. No action required; periodic check-in sufficient. |
| Healthy | 60–79 | Strong across most dimensions with identifiable room to grow. Coaching opportunity, not a rescue. |
| Watch | 40–59 | Meaningful gaps in engagement or outcomes. Proactive outreach warranted within the current month. |
| At Risk | 20–39 | Significant problems across multiple dimensions. Prioritize for active save play. |
| Critical | 0–19 | Severe disengagement or zero usage. Urgent intervention; escalate to executive if high ARR. |

---

## 5. Override Rules

Two overrides can cap the composite score downward. They exist because averages can sometimes produce misleading results when behavior tells a more urgent story.

### Ghost Account Override

**What it is:** Any client with $5,000 or more in ARR who has had zero logins in the last 90 days.

**Why it exists:** Operational signals — catalog completeness, import health — can look perfectly fine on an account where nobody has opened the app. Without this override, a well-maintained catalog and healthy data feeds could push a completely dormant account into the Healthy band, which would be deeply misleading.

**What it does:** Caps the composite score at 20 (Critical band), regardless of what the four dimensions compute. All four dimension scores are still shown — CSMs need to see what's working and what isn't. Lower-ARR accounts below the $5,000 threshold are not overridden; they may be on pause or in a different stage of their lifecycle.

### Behavioral Floor Override

**What it is:** Any account where Engagement scores below 55 AND Value Delivery scores below 40.

**Why it exists:** An account can score well on Adoption and Operational Health while users are barely showing up and the platform is producing no outcomes. A great catalog and healthy imports don't help a client who isn't using the product. This override prevents that combination from landing in the Healthy or Thriving bands.

**What it does:** Caps the composite score at 40 (top of the Watch band). All four dimension scores are still shown in full.

When either override applies, it is clearly labeled in the output so CSMs know why the composite differs from the average of the dimensions.

---

## 6. Key Design Decisions

- **Equal weights, on purpose.** All four dimensions contribute 25% each. We do not have enough outcome data yet (churned accounts, ARR changes) to know empirically which dimensions best predict retention for each product tier. Weighting by gut feel would be worse than not weighting at all. The plan is to run a formal correlation analysis once we have 3+ months of scores and 30+ labeled outcomes — and only introduce weights if the data clearly supports it.

- **No trajectory scoring.** Month-over-month trend is not a scored dimension. Trend direction is much more useful as context — surfaced in narrative, visible to the CSM — than as a mathematical input to the score. Scoring trend would require a longer baseline than we currently have, and would add complexity without clear explanatory value.

- **Seasonality is flagged, not suppressed.** If a measurement window falls during a known slow cycle for an industry (furniture, lighting, etc.), that context is noted alongside the score. The score itself is not adjusted. We don't yet have 12-month per-account baselines to normalize against, and adjusting scores algorithmically without that baseline would introduce noise, not signal.

- **Adoption and Value Delivery are unweighted point systems.** Every applicable feature or channel counts equally. An org with 200 presentations and an org with 2,000 portal orders are both delivering value through their primary channel. Neither outcome is privileged over the other in V1.

---

## 7. How the Key Thresholds Were Set

Each threshold in the model has a different origin. Here is the honest account of where each number came from.

### Login Volume Bands

These were derived from the actual distribution of logins across all 104 paying clients, measured in the trailing 90 days at the time of the first V3 run (May 2026):

| Percentile | Logins / 90 days |
|---|---|
| 10th | 97 |
| 25th | 314 |
| 50th (median) | 927 |
| 75th | 2,100 |
| 90th | 3,623 |

The band thresholds were placed at natural breaks in that distribution. The 200-login boundary (where the score steps up to 60) sits just below the 25th percentile, placing the lower quarter of the portfolio in the developing tier. The 1,000-login boundary sits near the median, giving the middle of the portfolio a score in the 75–88 range. The 3,000+ ceiling corresponds approximately to the 90th percentile.

These thresholds were not pulled from a benchmark or estimated in advance — they were set by observing where the client base actually clusters and where behavior meaningfully changes between groups.

### iPad Order Volume (≥ 10 orders)

The 10-order threshold was validated against the full portfolio distribution:

| Band | Clients |
|---|---|
| 1–4 orders | 7 |
| 5–9 orders | 7 |
| 10–29 orders | 13 |
| 30–49 orders | 5 |
| 50–99 orders | 10 |
| 100+ orders | 39 |

The 1–9 band is consistent with "one rep tested the feature." The 10+ band is consistent with genuine recurring workflow. A natural shoulder in the histogram falls around 10–30 orders. An earlier threshold of 50 (carried over from V2) was evaluated and rejected — it would have penalized 18 clients with real but modest order activity, including clients at 11–49 orders who are actively relying on the iPad for order capture.

At 10 orders over 90 days, the bar is approximately one order per week from a single rep — the minimum bar for "this client is actually capturing orders through the iPad."

### Sharing / Quoting Activity (≥ 3 events)

The 3-event threshold is a **conservatively low starting point**, not a validated threshold. The empirical analysis showed:

- 8 clients have zero sharing events
- 19 clients have 1–9 events (consistent with one-off tests)
- 62 clients have 30+ events (consistent with regular workflow)
- The median for clients with any sharing activity is 53 events

The data suggests the real "workflow-level" threshold is closer to 10 events per 90 days — roughly one share every nine days from a single rep. The 3-event threshold was retained for V3.0 to avoid false negatives during the first run. Raising it to 10 is a planned V3.2 refinement. Until then, clients in the 3–9 event range are technically passing this signal even though their usage pattern looks more like occasional testing than an established workflow.

### Health Bands (80 / 60 / 40 / 20)

The band boundaries are judgment calls anchored to CS workflow actions, not derived from a statistical model:

| Band | Score | Design intent |
|---|---|---|
| Thriving | 80–100 | Doing well across the board — periodic check-in only |
| Healthy | 60–79 | Strong but with identifiable room to grow — coaching opportunity |
| Watch | 40–59 | Meaningful gaps — proactive outreach this month |
| At Risk | 20–39 | Multiple problems across dimensions — active save play |
| Critical | 0–19 | Severe disengagement — escalate if high ARR |

The boundaries are round numbers because the underlying scoring mechanics (step-ladders, point ratios) do not produce enough precision to justify non-round boundaries. A threshold of 63 vs 60 would imply a level of measurement precision the signals don't actually have.

The 40-point boundary is the most operationally grounded: the Behavioral Floor override exists specifically to prevent a client from landing above Watch (above 40) when engagement and value delivery are both below their respective thresholds. That override was calibrated by manually reviewing client profiles during the first run.

**Validation plan:** The plan is to validate these thresholds retrospectively against churn outcomes once 3+ months of score history exists. If clients who churned were consistently in the Watch band 60+ days before leaving, the thresholds are well-placed. If they were landing in the Healthy band, the boundaries need to shift down. That analysis cannot run until sufficient outcome data is available — the subscription history table in the database was bulk-backfilled in mid-2025 and cannot be used as a churn source.

---

## 8. What This Is Not

**Interpretive narrative is a V3.1 target.** The current system produces factual summaries per dimension — counts, ratios, which channels are active. It does not yet produce the interpretive layer: "why is this score what it is, and what should the CSM do about it?" That capability is on the roadmap for the next iteration.

**Seasonality is acknowledged, not modeled.** The system flags when a score might reflect a known industry slow period, but it does not adjust scores accordingly. Without a full year of per-account history, any seasonal adjustment would be a guess. This is a known limitation until 12-month baselines are available.

**Dimension weights are not correlated to business outcomes yet.** The 25/25/25/25 weighting is an intentional starting point, not a validated model. A formal correlation study against retention and ARR outcomes will determine whether weighting is warranted — and if so, which dimensions carry the most predictive weight for which product tiers. That study cannot run until sufficient outcome data accumulates.

**Growth scoring is out of scope.** Expansion, upsell, and growth signals are a separate concern and are not included in the health score. The health score measures the health of what a client currently has — not the opportunity or likelihood of them buying more.

### Model Behavior Flags — Identified 2026-05-12

The following limitations were identified during the 7-org manual spot check (May 2026) and are targeted for V3.2. They do not represent bugs in the current scoring math — all scores are arithmetically correct per the V3.1 spec. They represent cases where a correct score can still produce a misleading CS picture.

| Flag | Description | Example Account | Planned Fix Version |
|------|-------------|----------------|---------------------|
| **A — Thriving with majority feeds broken** | An account can score Thriving if engagement, adoption, and value delivery are strong — even if the majority of import feeds are erroring. Operational health contributes only 25% of the composite. A CSM receiving a Thriving account with 4 of 6 feeds broken will reasonably deprioritize it. | `sbl` (84.0 Thriving; 4/6 feeds erroring; Customers feed 141 days stale) | V3.2 |
| **B — Import health passes despite universal staleness** | The import health sub-signal checks whether the last run errored, not whether it ran recently. A feed that has simply stopped running without erroring will score healthy on import health. Feeds with fewer than 3 runs in 180 days are also excluded from freshness scoring — making them invisible to the entire model. | `ihm` (4/4 import health pass; all feeds 35–106 days stale; Inventory and Product Stories excluded from freshness due to <3 runs) | V3.2 |
| **C — Denominator inflation for iPad+Catalog+Portal bundles** | The denominator switch (replacing `enabled_users` with `active_users_365d` when `enabled_users > 500`) covers Full and iPad+Catalog+Cart bundles only. iPad+Catalog+Portal orgs with large B2B buyer bases are not covered. Portal buyer accounts inflating `org_users` produce artificially low active-user ratios and engagement scores for these orgs. | `clm` (745 `enabled_users` likely inflated by portal buyer accounts; apparent ratio 8.7% vs. estimated internal rep ratio of 65%+) | V3.2 |
| **D — Multifile Import burst-weight persists 180 days after feed retirement** | If an org ran a large Multifile Import migration (thousands of runs in a short burst) and then permanently retired the feed type, the burst run-count anchors the freshness weighted average near zero for the full 180-day window — even if all other active feeds are healthy. | `clm` (5,253 Multifile Import runs in 5 days, Apr 8–13 2026; anchors freshness average until ~Oct 2026; ops health capped ~75 regardless of other feed performance) | V3.2 |

**Note:** Flag E (sharing threshold ≥ 3 events is below workflow-level) is documented separately in the threshold rationale section. It is already planned for V3.2.
